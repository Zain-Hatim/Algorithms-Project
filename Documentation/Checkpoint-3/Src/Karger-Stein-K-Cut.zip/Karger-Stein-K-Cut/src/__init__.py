"""
Karger-Stein algorithm for finding minimum k-cuts in graphs.
"""

__version__ = '0.1.0'

# Karger-Stein K-Cut package 